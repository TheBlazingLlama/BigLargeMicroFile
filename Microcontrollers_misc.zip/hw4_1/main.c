/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
/******************************************************************************
 * MSP432 Empty Project
 *
 * Description: An empty project that uses DriverLib
 *
 *                MSP432P4111
 *             ------------------
 *         /|\|                  |
 *          | |                  |
 *          --|RST               |
 *            |                  |
 *            |                  |
 *            |                  |
 *            |                  |
 *            |                  |
 * Author: 
*******************************************************************************/
/* DriverLib Includes */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
typedef enum {S0, S1, S2, S3} states;
typedef enum {reset, b1, b2} button_events;
static volatile button_events button_press;
static volatile uint8_t event_flag = 0;
int main(void)
{
    /* Stop Watchdog  */
    MAP_WDT_A_holdTimer();
    MAP_GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2);
     MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2);
     MAP_GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1, GPIO_PIN1|GPIO_PIN4|GPIO_PIN5);
      MAP_GPIO_clearInterruptFlag(GPIO_PORT_P1, GPIO_PIN1|GPIO_PIN4|GPIO_PIN5);
      MAP_GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN1|GPIO_PIN4|GPIO_PIN5);
      MAP_Interrupt_enableInterrupt(INT_PORT1);

      /* Enabling MASTER interrupts */
      MAP_Interrupt_enableMaster();
      states n_s;
       states p_s = S0;
       while (1)
        {
        MAP_PCM_gotoLPM3(); // Low Power Mode 3 deep sleep
        while (!event_flag){};
        if (button_press == reset) {
        n_s = S0;
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN0);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN2);
        }
        else {
        if (p_s == S0) {
        if (button_press == b2) {
        n_s = S1;
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN0);
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN1);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN2);
        }
        else if (button_press == b1) {n_s = S0;
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN0);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN2);
        }
        }

        else if (p_s == S1) {
        if (button_press == b1) {
        n_s = S0;
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN0);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN2);
        }
        else if (button_press == b2) {
        n_s = S2;
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN0);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN2);
        }
        }
        else if (p_s == S2) {
        if (button_press == b1) {
        n_s = S3;
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN0);
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN1);
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN2);
        }
        else if (button_press == b2) {
        n_s = S2;
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN0);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN2);
        }
        }
        else if (p_s == S3) {
        if (button_press == b1) {
        n_s = S0;
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN0);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN1);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN2);
        }
        else if (button_press == b2) {
        n_s = S1;
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN0);
        MAP_GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN1);
        MAP_GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN2);
        }
         }
         p_s = n_s; // state transition
         event_flag = 0;
         }
         }
        }
        void PORT1_IRQHandler(void)
        {
         uint32_t status;
         status = MAP_GPIO_getEnabledInterruptStatus(GPIO_PORT_P1);
         MAP_GPIO_clearInterruptFlag(GPIO_PORT_P1, status);
         if (status & GPIO_PIN5) button_press = reset;
         else if (status & GPIO_PIN4) button_press = b2;
         else if (status & GPIO_PIN1) button_press = b1;
         event_flag = 1;
        }
